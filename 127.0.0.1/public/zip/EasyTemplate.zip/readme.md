EasyTemplate
============

A simple cross-platform Node.js template manager

No doc actually, it's only a P.O.C. to support my online advices.

[A PHP equivalent](http://easytemplate.lcfvs.com) exists, fully open source, with the same coding style & based on my [DynHtaccess](https://github.com/Lcfvs/DynHtaccess).
